#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>
#include <glut.h>

#define pi (2*acos(0.0))

int sph,scl,posx,inc;
double ang;
int drawgrid;
int drawaxes;
double angle;

struct point
{
	double x,y,z;
};

double cameraLookingX = 0;
double cameraLookingY = 0;
double cameraLookingZ = 0;


double cameraAngle =1.0;
double cameraRadius = 300;

double cameraX = 30;
double cameraY = 300;
double cameraHeight = 150;

double cameraAngleDelta = -0.0003;

double move_X = 0;
double move_Y = 0;
double move_Z = 0;
double speed = 30;
double ang_speed = 0.5;
int num_texture = -1;

GLuint abc,def,mn;


/***************************** Texture Functions *******************************/

int loadBitmapImage(char *filename)
{
	int i, j = 0;
	FILE *l_file;
	unsigned char *l_texture;

	BITMAPFILEHEADER fileheader;
	BITMAPINFOHEADER infoheader;
	RGBTRIPLE rgb;

	num_texture++;

	if ((l_file = fopen(filename, "rb")) == NULL)
	{
		return (-1);
	}

	fread(&fileheader, sizeof(fileheader), 1, l_file);

	fseek(l_file, sizeof(fileheader), SEEK_SET);
	fread(&infoheader, sizeof(infoheader), 1, l_file);

	l_texture = (byte *)malloc(infoheader.biWidth * infoheader.biHeight * 4);
	memset(l_texture, 0, infoheader.biWidth * infoheader.biHeight * 4);
	for (i = 0; i < infoheader.biWidth * infoheader.biHeight; i++)
	{
		fread(&rgb, sizeof(rgb), 1, l_file);

		l_texture[j + 0] = rgb.rgbtRed;
		l_texture[j + 1] = rgb.rgbtGreen;
		l_texture[j + 2] = rgb.rgbtBlue;
		l_texture[j + 3] = 255;
		j += 4;
	}
	fclose(l_file);

	glBindTexture(GL_TEXTURE_2D, num_texture);

	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);

	// glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glTexImage2D(GL_TEXTURE_2D, 0, 4, infoheader.biWidth, infoheader.biHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, l_texture);
	gluBuild2DMipmaps(GL_TEXTURE_2D, 4, infoheader.biWidth, infoheader.biHeight, GL_RGBA, GL_UNSIGNED_BYTE, l_texture);

	free(l_texture);

	return (num_texture);
}

void loadAllImages()
{
	def = loadBitmapImage("1.bmp");
	abc = loadBitmapImage("2.bmp");
    mn = loadBitmapImage("3.bmp");

}


/****************************** GridLines and Axes ***********************************/

void drawAxes()
{

		glBegin(GL_LINES);{
		    glColor3f(0, 1.0, 0);
			glVertex3f( 1000,0,0);
			glVertex3f(-1000,0,0);

			glColor3f(0, 0, 1.0);
			glVertex3f(0,-1000,0);
			glVertex3f(0, 1000,0);

			glColor3f(1.0, 1.0, 1.0);
			glVertex3f(0,0, 1000);
			glVertex3f(0,0,-1000);
		}glEnd();

}


void display()
{
	//codes for Models, Camera

	//clear the display
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0, 0, 0, 0);    //color black
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);        //clear buffers to preset values

															   /***************************
															   / set-up camera (view) here
															   ****************************/
															   //load the correct matrix -- MODEL-VIEW matrix
	glMatrixMode(GL_MODELVIEW);        //specify which matrix is the current matrix

									   //initialize the matrix
	glLoadIdentity();                //replace the current matrix with the identity matrix [Diagonals have 1, others have 0]

									 //now give three info
									 //1. where is the camera (viewer)?
									 //2. where is the camera looking?
									 //3. Which direction is the camera's UP direction?

    gluLookAt(200*cos(cameraAngle), 200*sin(cameraAngle), cameraHeight,		0,0,0,		0,0,1);
	//gluLookAt(cameraX, cameraY, cameraHeight, cameraLookingX, cameraLookingY, cameraLookingZ, 0, 0, 1);
	//gluLookAt(cameraRadius * sin(cameraAngle), -cameraRadius * cos(cameraAngle), cameraHeight, cameraLookingX, cameraLookingY, cameraLookingZ, 0, 0, 1);


	glMatrixMode(GL_MODELVIEW);


	/**************************************************
	/ Grid and axes Lines(You can remove them if u want)
	***************************************************/

	drawAxes();


						/****************************
						/ Add your objects from here
						****************************/



	glPushMatrix();
	{

		glEnable(GL_TEXTURE_2D);
		{
		    glBindTexture(GL_TEXTURE_2D, def);

			glPushMatrix();
			{
				glColor3f(1, 1, 1);
				GLUquadricObj *obj = gluNewQuadric();
				gluQuadricTexture(obj, GL_TRUE);
				gluCylinder(obj, 0, 20, 50,100,100);

			}
			glPopMatrix();

			  glBindTexture(GL_TEXTURE_2D,abc);


			glPushMatrix();
			{
				glColor3f(1, 1, 1);
				GLUquadricObj *obj = gluNewQuadric();
				gluQuadricTexture(obj, GL_TRUE);
				glTranslated(0,0,55);
				gluSphere(obj, 20, 20, 50);

			}
			glPopMatrix();

 glBindTexture(GL_TEXTURE_2D, abc);
			glPushMatrix();
			{
				glColor3f(1, 1, 1);
				GLUquadricObj *obj = gluNewQuadric();
				gluQuadricTexture(obj, GL_TRUE);
				glTranslated(10,0,65);
				gluSphere(obj, 20, 20, 50);

			}
			glPopMatrix();


}
		glDisable(GL_TEXTURE_2D);


	}
	glPopMatrix();


	//ADD this line in the end --- if you use double buffer (i.e. GL_DOUBLE)
	glFlush();
	glutSwapBuffers();
}

void animate()
{
	glutPostRedisplay();    //this will call the display AGAIN

}

void init()
{
	glClearColor(0, 0, 0, 0);

	/************************
	/ set-up projection here
	************************/
	//load the PROJECTION matrix
	glMatrixMode(GL_PROJECTION);

	//initialize the matrix
	glLoadIdentity();

	/*
	gluPerspective() � set up a perspective projection matrix

	fovy -         Specifies the field of view angle, in degrees, in the y direction.
	aspect ratio - Specifies the aspect ratio that determines the field of view in the x direction. The aspect ratio is the ratio of x (width) to y (height).
	zNear -        Specifies the distance from the viewer to the near clipping plane (always positive).
	zFar  -        Specifies the distance from the viewer to the far clipping plane (always positive).
	*/

	gluPerspective(70, 1, 0.1, 10000.0);

}

void keyboardListener(unsigned char key, int x, int y)
{
	switch (key)
	{

	case '+':
		break;

	case '-':
		break;

	case 'l':
	case 'L':
		break;

	case 'r':
	case 'R':
		break;

	case 'q':
	case 'Q':
		break;

	case 'e':
	case 'E':
		break;


	default:
		break;
	}
}

void specialKeyListener(int key, int x,int y){
	switch(key){
		case GLUT_KEY_DOWN:		//down arrow key
			cameraHeight -= 3.0;
			break;
		case GLUT_KEY_UP:		// up arrow key
			cameraHeight += 3.0;
			break;

		case GLUT_KEY_RIGHT:
			cameraAngle += 0.03;
			break;
		case GLUT_KEY_LEFT:
			cameraAngle -= 0.03;
			break;

		case GLUT_KEY_PAGE_UP:
			break;
		case GLUT_KEY_PAGE_DOWN:
			break;

		case GLUT_KEY_INSERT:
			break;

		case GLUT_KEY_HOME:

			break;
		case GLUT_KEY_END:
			break;

		default:
			break;
	}
}

void mouseListener(int button, int state, int x, int y)
{    //x, y is the x-y of the screen (2D)
	switch (button)
	{
	case GLUT_LEFT_BUTTON:
		if (state == GLUT_DOWN)
		{
			// 2 times?? in ONE click? -- solution is checking DOWN or UP
		}
		break;

	case GLUT_RIGHT_BUTTON:
		//........
		break;

	case GLUT_MIDDLE_BUTTON:
		//........
		break;

	default:
		break;
	}
}

int main(int argc, char **argv)
{
	glutInit(&argc, argv);                            //initialize the GLUT library

	glutInitWindowSize(600, 600);
	glutInitWindowPosition(0, 0);

	/*
	glutInitDisplayMode - inits display mode
	GLUT_DOUBLE - allows for display on the double buffer window
	GLUT_RGBA - shows color (Red, green, blue) and an alpha
	GLUT_DEPTH - allows for depth buffer
	*/
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);

	glutCreateWindow("Some Title");

	printf("Camera Controls\n\n");
	printf("Roll: UP and DOWN arrow\n");
	printf("Pitch: Q and E\n");
	printf("Yaw: LEFT and RIGHT arrow\n");
	printf("Up-Down: PAGEUP and PAGEDOWN\n");
	printf("Left-Right: L and R\n");
	printf("Zoom in-out: + and -\n");
	printf("Reset Camera: HOME\n");

	init();                        //codes for initialization

	loadAllImages();

	glEnable(GL_DEPTH_TEST);    //enable Depth Testing

								//loadAllImages();

	glutDisplayFunc(display);    //display callback function
	glutIdleFunc(animate);        //what you want to do in the idle time (when no drawing is occuring)

	glutKeyboardFunc(keyboardListener);
	glutSpecialFunc(specialKeyListener);

	glutMouseFunc(mouseListener);

	glutMainLoop();        //The main loop of OpenGL

	return 0;
}
