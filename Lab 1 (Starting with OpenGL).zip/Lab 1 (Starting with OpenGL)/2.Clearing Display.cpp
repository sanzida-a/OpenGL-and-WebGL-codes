void display(){
	//codes for Models, Camera
	
	//clear the display
	glClearColor(0,0,0,0);	//color black
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);		//clear buffers to preset values

	/****************************
	/ Add your objects from here
	****************************/
	//Make a story board first

	//ADD this line in the end --- if you use double buffer (i.e. GL_DOUBLE)
	glutSwapBuffers();
}
